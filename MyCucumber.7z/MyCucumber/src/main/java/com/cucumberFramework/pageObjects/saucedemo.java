package com.cucumberFramework.pageObjects;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.cucumberFramework.helper.AbstractPage;
import com.cucumberFramework.helper.WaitHelper;

public class saucedemo extends AbstractPage {

	
	private WebDriver driver;
	WaitHelper waitHelper;
	
	@FindBy(id="user-name")
	public WebElement usernameTxt;
	
	@FindBy(id="password")
	public WebElement passwordTxt;

	@FindBy(id="login-button")
	public WebElement loginBtn;
	
	@FindBy(className="product_sort_container")
	public WebElement filterDrp;
	
	@FindBy(xpath="//*[@id='header_container']/div[2]/div[2]/span/select/option[1]")
	public WebElement defaultFilter;
	
	
	@FindBy(id="add-to-cart-sauce-labs-onesie")
	public WebElement firstItemAdd;
	
	@FindBy(id="add-to-cart-sauce-labs-fleece-jacket")
	public WebElement lastItemAdd;
	
	@FindBy(xpath="//*[@id='item_5_title_link']/div")
	public WebElement lastItemName;
	
	@FindBy(xpath="//*[@id='inventory_container']/div/div[6]/div[2]/div[2]/div")
	public WebElement lastItemPrice;
	
	@FindBy(id="remove-sauce-labs-onesie")
	public WebElement firstItemRemove ;
	
	@FindBy(id="shopping_cart_container")
	public WebElement cartIcon;
	
	@FindBy(className="inventory_item_name")
	public WebElement inventoryItemName;
	
	@FindBy(className="inventory_item_price")
	public WebElement inventoryItemPrice;
	
	
	public saucedemo(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
		waitHelper = new WaitHelper(driver);
	}
	
	public void navigateToPage() {
		String url= "https://www.saucedemo.com/";
		driver.get(url);
	}
	
	public void checkPageTitle(String pageTitle) {
		String currentTitle= driver.getTitle();
		assertTrue(currentTitle.contains(pageTitle));
	}
	
	public void login (String username, String password) {
		waitHelper.WaitForElement(this.usernameTxt, 3);
		this.usernameTxt.sendKeys(username);
		waitHelper.WaitForElement(this.passwordTxt, 3);
		this.passwordTxt.sendKeys(password);
		waitHelper.WaitForElement(this.loginBtn, 3);
		this.loginBtn.click();
	}
	
	public void checkDefaultFilter() {
		waitHelper.WaitForElement(this.defaultFilter, 3);
		assertTrue(defaultFilter.isSelected());
	}
	
	public void changeFilter() {
		Select mSelect = new Select(filterDrp);
		mSelect.selectByValue("lohi");
	}
	
	public void addFirstItem() {
		waitHelper.WaitForElement(this.firstItemAdd, 3);
		this.firstItemAdd.click();
	}
	
	public void checkNumberProduct(String number) {
		waitHelper.WaitForElement(this.cartIcon, 3);
		String actualNumberProduct= cartIcon.getText();
		assertTrue(actualNumberProduct.contains(number));
	}
	
	public void addLastItem() {
		waitHelper.WaitForElement(this.lastItemAdd, 3);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView(true);",lastItemAdd);
		this.lastItemAdd.click();
	}
	
	public void removeFirstItem() {
		Actions act= new Actions(driver);
		act.keyDown(Keys.CONTROL).build().perform();
		act.sendKeys(Keys.HOME).build().perform();
        act.keyUp(Keys.CONTROL).build().perform();
        waitHelper.WaitForElement(this.cartIcon, 10);
		this.firstItemRemove.click();
	}
	
	public void clickCart() {
		waitHelper.WaitForElement(this.cartIcon, 200);
		this.cartIcon.click();
	}
	
	public void checkNamePrice(String act_selectedName, String act_selectedPrice ) {
		
		waitHelper.WaitForElement(this.inventoryItemName, 3);
		String nameItemOnCart = inventoryItemName.getText();
		waitHelper.WaitForElement(this.inventoryItemPrice, 3);
		String priceItemOnCart = inventoryItemPrice.getText();
		assertTrue(nameItemOnCart.contains(act_selectedName));
		assertTrue(priceItemOnCart.contains(act_selectedPrice));

	}
	
}