package com.cucumberFramework.stepdefinitions;

import com.cucumberFramework.helper.WaitHelper;
import com.cucumberFramework.pageObjects.saucedemo;
import com.cucumberFramework.testBase.TestBase;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class saucedemoStepsDefinitions extends TestBase  {

	saucedemo saucedemo = new saucedemo(driver);
	WaitHelper waitHelper = new WaitHelper(driver);
	
	@Given("^Being on saucedemo$")
	public void being_on_saucedemo() throws Throwable {
		saucedemo.navigateToPage();
	}

	@Then("^See the title as \"([^\"]*)\"$")
	public void see_the_title_as(String pageTitle) throws Throwable {
	    saucedemo.checkPageTitle(pageTitle);
	}

	@When("^Login with username as \"([^\"]*)\" and password as \"([^\"]*)\"$")
	public void login_with_username_as_and_password_as(String username, String password) throws Throwable {
		saucedemo.login(username, password);
	}

	@Then("^See default filter dropdown is as NAME A to Z$")
	public void see_default_filter_dropdown_is_as_NAME_A_to_Z() throws Throwable {
	    saucedemo.checkDefaultFilter();
	}

	@When("^Change the price filter from low to high$")
	public void change_the_price_filter_from_low_to_high() throws Throwable {
		saucedemo.changeFilter();
	}

	@When("^Add the first product to the cart$")
	public void add_the_first_product_to_the_cart() throws Throwable {
	    saucedemo.addFirstItem();
	}

	@Then("^See the number product of the cart badge is  as \"([^\"]*)\"$")
	public void see_the_number_product_of_the_cart_badge_is_as(String number) throws Throwable {
		saucedemo.checkNumberProduct(number);
	}

	@When("^Add the last product to the cart$")
	public void add_the_last_product_to_the_cart() throws Throwable {
		saucedemo.addLastItem();
	}

	@When("^Remove the first product from the cart$")
	public void remove_the_first_product_from_the_cart() throws Throwable {
	    saucedemo.removeFirstItem();
	}

	@When("^Click on the cart$")
	public void click_on_the_cart() throws Throwable {
	    saucedemo.clickCart();
	}

	@Then("^the added product is available with name as \"([^\"]*)\" and price as \"([^\"]*)\"$")
	public void the_added_product_is_available_with_name_as_and_price_as(String name, String price) throws Throwable {
	    saucedemo.checkNamePrice(name, price);
	}

}
